from Crypto.Cipher import AES

class cipherAES(object):
    def __init__(self, key):
        self.key = key
        self.paddedKey = self.PAD(self.key)
        self.cipher = AES.new(self.paddedKey)
    
    def PAD(self, var):
        l_obj = len(var)%16
        if (l_obj == 0):
            return var
        else:
            return (var + 'X'*(16-l_obj))
            
    
    def encryptText(self, plainText):
        paddedText = self.PAD(plainText)
        return self.cipher.encrypt(paddedText)
    
    def decryptText(self, encryptedText):
        return self.cipher.decrypt(encryptedText)


if __name__=="__main__":
    aes = cipherAES('///&&')
    plainText = input('Enter text to encrypt: ')
    enc = aes.encryptText(plainText)
    print('Encrypted Text: ' + str(enc))
    print('Decrypted Text: ' + str(aes.decryptText(enc))[2: len(plainText)+2])
