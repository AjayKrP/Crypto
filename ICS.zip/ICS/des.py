from Crypto.Cipher import DES

class cipherDES(object):
    def __init__(self, key):
        self.key = key
        self.paddedKey = self.PAD(self.key)
        self.cipher = DES.new(self.paddedKey)
    
    def PAD(self, var):
        l_obj = len(var)%8
        if (l_obj == 0):
            return var
        else:
            return (var + 'X'*(8-l_obj))
            
    
    def encryptText(self, plainText):
        paddedText = self.PAD(plainText)
        return self.cipher.encrypt(paddedText)
    
    def decryptText(self, encryptedText):
        return self.cipher.decrypt(encryptedText)

if __name__ == "__main__":
    des = cipherDES('///&&')
    plainText = input('Enter text to encrypt: ')
    enc = des.encryptText(plainText)
    print('Encrypted Text: ' + str(enc))
    print('Decrypted Text: ' + str(des.decryptText(enc))[2: len(plainText)+2])
