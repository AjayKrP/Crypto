class DiffieHellman(object):
    def calculateValue(self, a, b, P):
        return pow(int(a), int(b))%int(P)
    
    def operation(self):
        P = input('Enter value of P? ')
        G = input('Enter value of G? ')
        a = input('Enter the private key for Alice? ')
        X = self.calculateValue(G, a, P)
        print('Public key for Alice: ' + str(X))
        b = input('Enter the private key for Bob? ')
        Y = self.calculateValue(G, b, P)
        print('Public key for Bob: ' + str(Y))
        ka = self.calculateValue(Y, a, P);
        kb = self.calculateValue(X, b, P);
        print('Symmetric keys for the Alice is: '+ str(ka))
        print('Symmetric keys for the Bob is: '+ str(kb))
        print('So '+ str(ka) +' is the shared secret key.')

if __name__ == "__main__":
    dh = DiffieHellman()
    dh.operation()
