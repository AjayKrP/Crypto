# Returns gcd of a and b 
def gcd(a, h):
    temp = 0
    while (True):
        temp = a%h;
        if (temp == 0):
            return h
        a = h
        h = temp; 

if __name__=='__main__':
    p = int(input('Enter value of p? ')) 
    q = int(input('Enter value of q? '))
    n = p*q; 
    e = 2; 
    phi = (p-1)*(q-1); 
    while (e < phi): 
        if (gcd(e, phi) == 1): 
            break; 
        else:
            e += 1
            
    k = 2;  # A constant value 
    d = (1 + (k*phi))/e; 
  
    # Message to be encrypted 
    msg = int(input('Enter message? '))
  
    print("Message data: ", msg); 
  
    # Encryption c = (msg ^ e) % n 
    c = pow(msg, e); 
    c = c % n
    print("\nEncrypted data: ", c); 
  
    # Decryption m = (c ^ d) % n 
    m = pow(c, d); 
    m = m % n
    print("\nOriginal Message Sent: ", m); 
 
