import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import export_graphviz
import pydotplus
from sklearn.externals.six import StringIO

# reading Dataset
data = pd.read_csv("d_tree.csv")
columns = data.columns


encoder = LabelEncoder()

# Label Encoding
for i in range(5):
    data.iloc[:, i] = encoder.fit_transform(data.iloc[:, i].astype(str))

X = data.iloc[:, :-1]
y = data.iloc[:, 4]

reg = DecisionTreeClassifier()
reg.fit(X, y)

# Predict value for the given Expression
X_in = np.array([1, 1, 0, 0])
y_pred = reg.predict([X_in])
print("Prediction:", y_pred)

dot_data = StringIO()

export_graphviz(reg, out_file=dot_data, filled=True, rounded=True, special_characters=True)
graph = pydotplus.graph_from_dot_data(dot_data.getvalue())
graph.write_png('tree.png')
