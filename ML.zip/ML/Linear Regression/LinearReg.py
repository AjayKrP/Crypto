from sklearn.linear_model import LinearRegression
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('linear.csv')
X = data.iloc[:, :-1].values
y = data.iloc[:, 1].values

# Build Model
reg = LinearRegression()
reg.fit(X, y)

# Find Accuracy
Accuracy = reg.score(X, y) * 100
print(Accuracy)

# Predict Value
y_pred = reg.predict([[10]])
print(y_pred)

# Calculate Risk Score
hours = int(input('Enter the no of hours: '))
equation = reg.coef_ * hours + reg.intercept_
print('%f * %f + %f' % (reg.coef_, hours, reg.intercept_))
print("Risk Score : ", equation[0])

# Plot Graph
plt.plot(X, y, 'o')
plt.plot(X, reg.predict(X))
plt.show()
